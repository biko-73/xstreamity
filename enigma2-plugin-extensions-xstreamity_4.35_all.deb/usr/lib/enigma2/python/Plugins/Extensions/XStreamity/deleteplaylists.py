#!/usr/bin/python
# -*- coding: utf-8 -*-

from . import _
from .xStaticText import StaticText
from .plugin import skin_directory, playlists_json, playlist_file, cfg, common_path

from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap

import json
import os
import shutil


class XStreamity_DeletePlaylists(Screen):
    def __init__(self, session):

        Screen.__init__(self, session)
        self.session = session

        skin_path = os.path.join(skin_directory, cfg.skin.getValue())
        skin = os.path.join(skin_path, "selectlist.xml")
        with open(skin, "r") as f:
            self.skin = f.read()

        self.setup_title = _("Delete Dead Playlists")

        # new list code
        self.start_list = []
        self.draw_list = []
        self["list"] = List(self.draw_list, enableWrapAround=True)

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Delete"))
        self["key_yellow"] = StaticText(_("Invert"))
        self["key_blue"] = StaticText(_("Clear All"))
        self["key_info"] = StaticText("")
        self["version"] = StaticText("")

        if os.path.isfile(playlists_json):
            with open(playlists_json, "r") as f:
                try:
                    self.playlists_all = json.load(f)
                    self.playlists_all.sort(key=lambda e: e["playlist_info"]["index"], reverse=False)
                except:
                    pass

        self.onLayoutFinish.append(self.__layoutFinished)

        self["actions"] = ActionMap(["XStreamityActions"], {
            "red": self.keyCancel,
            "green": self.deletePlaylist,
            "yellow": self.toggleAllSelection,
            "blue": self.clearAllSelection,
            "cancel": self.keyCancel,
            "ok": self.toggleSelection
        }, -2)

        self.getStartList()
        self.refresh()

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def buildListEntry(self, name, index, selected):
        if selected:
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "lock_off.png"))
        else:
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "lock_on.png"))
        return (pixmap, str(name), index, selected)

    def getStartList(self):
        for playlist in self.playlists_all:

            if playlist["data"]["fail_count"] != 0:
                self.start_list.append([str(playlist["playlist_info"]["name"]), playlist["playlist_info"]["index"], False])

        self.draw_list = [self.buildListEntry(x[0], x[1], x[2]) for x in self.start_list]
        self["list"].setList(self.draw_list)

    def refresh(self):
        self.draw_list = []
        self.draw_list = [self.buildListEntry(x[0], x[1], x[2]) for x in self.start_list]
        self["list"].updateList(self.draw_list)

    def toggleSelection(self):
        if len(self["list"].list) > 0:
            idx = self["list"].getIndex()
            self.start_list[idx][2] = not self.start_list[idx][2]
            self.refresh()

    def toggleAllSelection(self):
        for idx, item in enumerate(self["list"].list):
            self.start_list[idx][2] = not self.start_list[idx][2]
        self.refresh()

    def getSelectionsList(self):
        return [item[0] for item in self.start_list if item[2]]

    def clearAllSelection(self):
        for idx, item in enumerate(self["list"].list):
            self.start_list[idx][2] = False
        self.refresh()

    def keyCancel(self):
        self.close()

    def deletePlaylist(self):
        selected_playlists_list = self.getSelectionsList()

        for z in selected_playlists_list:
            playlist_name = z

            name = ""
            domain = ""
            username = ""

            for playlist in self.playlists_all:

                name = str(playlist["playlist_info"]["name"])
                domain = str(playlist["playlist_info"]["domain"])
                username = str(playlist["playlist_info"]["username"])

                if str(playlist_name) == str(name):

                    with open(playlist_file, "r+") as f:
                        lines = f.readlines()
                        f.seek(0)
                        f.truncate()
                        for line in lines:
                            if domain in line and "username=" + username in line:
                                line = "#%s" % line
                            f.write(line)

                    del playlist
                    break

            self.writeJsonFile()

            epglocation = str(cfg.epglocation.value)
            epgfolder = os.path.join(epglocation, name)

            try:
                shutil.rmtree(epgfolder)
            except:
                pass

        self.close()

    def writeJsonFile(self):
        with open(playlists_json, "w") as f:
            json.dump(self.playlists_all, f)

#!/usr/bin/python
# -*- coding: utf-8 -*-


from time import time

import os
try:
    import cPickle
except:
    import _pickle as cPickle


def setResumePoint(session):
    global resumePointCache, resumePointCacheLast
    service = session.nav.getCurrentService()
    ref = session.nav.getCurrentlyPlayingServiceReference()
    if (service is not None) and (ref is not None):  # and (ref.type != 1):

        # ref type 1 has its own memory...
        seek = service.seek()
        if seek:
            pos = seek.getPlayPosition()
            if not pos[0]:
                key = ref.toString()
                lru = int(time())
                l = seek.getLength()
                if l:
                    l = l[1]
                else:
                    l = None
                resumePointCache[key] = [lru, pos[1], l]
                saveResumePoints(session)


def getResumePoint(ref):
    global resumePointCache
    resumePointCache = loadResumePoints(ref)
    if (ref is not None) and (ref.type != 1):
        try:
            entry = resumePointCache[ref.toString()]
            entry[0] = int(time())  # update LRU timestamp
            last = entry[1]
            length = entry[2]
            return last, length
        except KeyError:
            last = None
            length = 0
            return last, length


def saveResumePoints(session):
    global resumePointCache, resumePointCacheLast
    service = session.nav.getCurrentService()
    if not os.path.exists('/etc/enigma2/xstreamity-resumepoints.pkl'):
        with open('/etc/enigma2/xstreamity-resumepoints.pkl', "w"):
            pass

    try:
        f = open('/etc/enigma2/xstreamity-resumepoints.pkl', 'wb')
        cPickle.dump(resumePointCache, f, cPickle.HIGHEST_PROTOCOL)
        f.close()
    except Exception as ex:
        print("[XStreamity] Failed to write resumepoints:", ex)


def loadResumePoints(ref):
    try:
        file = open('/etc/enigma2/xstreamity-resumepoints.pkl', 'rb')
        PickleFile = cPickle.load(file)
        file.close()
        return PickleFile
    except Exception as ex:
        print("[XStreamity] Failed to load resumepoints:", ex)
        return {}


resumePointCache = {}
